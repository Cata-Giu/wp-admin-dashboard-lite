<?php
$user = wp_get_current_user();
?>

<div class="wpdl-dashboard-wrapper" style="display: flex; height: 100%; min-height: 600px;">
    <aside class="wpdl-sidebar" style="width: 250px; background: #23282d; color: white; padding: 20px;">
        <div style="text-align: center; margin-bottom: 20px;">
            <?php echo get_avatar($user->ID, 64); ?>
            <p style="margin-top: 10px;"><?php echo esc_html($user->display_name); ?></p>
        </div>
        <nav>
            <ul style="list-style: none; padding-left: 0;">
                <li><a href="?wpdl-page=dashboard" style="color: white;">📊 Dashboard</a></li>
                <li><a href="?wpdl-page=coupons" style="color: white;">🎟️ Coupon</a></li>
                <li><a href="?wpdl-page=orders" style="color: white;">📦 Ordini</a></li>
                <li><a href="?wpdl-page=products" style="color: white;">🛒 Prodotti</a></li>
                <li><a href="?wpdl-page=add-product" style="color: white;">➕ Aggiungi prodotto</a></li>
                <li><a href="?wpdl-page=reports" style="color: white;">📈 Report</a></li>

            </ul>
        </nav>
    </aside>

    <main class="wpdl-main-content" style="flex: 1; background: #f9f9f9; padding: 20px;">

<div id="wpdl-content">
    <?php
    $current_page = isset($_GET['wpdl-page']) ? sanitize_text_field($_GET['wpdl-page']) : 'dashboard';

    switch ($current_page) {
        case 'orders':
            include WPDL_PATH . 'templates/orders.php';
            break;
        case 'products':
            include WPDL_PATH . 'templates/products.php';
            break;
        case 'add-product':
            include WPDL_PATH . 'templates/add-products.php';
            break;
        case 'coupons':
            include WPDL_PATH . 'templates/coupons.php';
            break;
        case 'reports':
            include WPDL_PATH . 'templates/reports.php';
            break;
        case 'dashboard':
        default:
            $stats = WP_Admin_Dashboard_Stats::get_stats();
            ?>
            <h2>Dashboard</h2>
            <div style="display: flex; gap: 20px; flex-wrap: wrap;">
                <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; flex: 1;">
                    <h3>Vendite nette (mese)</h3>
                    <p style="font-size: 1.5em; font-weight: bold;"><?php echo $stats['total_sales']; ?></p>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; flex: 1;">
                    <h3>Ordini completati</h3>
                    <p style="font-size: 1.5em; font-weight: bold;"><?php echo $stats['completed_orders']; ?></p>
                </div>
                <div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; flex: 1;">
                    <h3>Prodotti esauriti</h3>
                    <p style="font-size: 1.5em; font-weight: bold;"><?php echo $stats['out_of_stock']; ?></p>
                </div>
            </div>
            <?php
            break;
    }
    ?>
</div>


    </main>
</div>
