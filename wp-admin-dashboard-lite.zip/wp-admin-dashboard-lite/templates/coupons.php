<?php
if (!function_exists('post_exists')) {
    require_once ABSPATH . 'wp-admin/includes/post.php';
}

if (!current_user_can('manage_woocommerce')) {
    echo '<p>Accesso negato.</p>';
    return;
}

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wpdl_add_coupon_nonce']) && wp_verify_nonce($_POST['wpdl_add_coupon_nonce'], 'wpdl_add_coupon')) {
    $code = sanitize_text_field($_POST['code']);
    $discount_type = sanitize_text_field($_POST['discount_type']);
    $amount = floatval($_POST['amount']);
    $expiry_date = sanitize_text_field($_POST['expiry_date']);

    if (empty($code)) {
        $error = 'Il codice coupon è obbligatorio.';
    } else {
        // Verifica se coupon esiste già
        if (post_exists($code, '', '', 'shop_coupon')) {
            $error = 'Un coupon con questo codice esiste già.';
        } else {
            $coupon = array(
                'post_title'   => $code,
                'post_content' => '',
                'post_status'  => 'publish',
                'post_author'  => get_current_user_id(),
                'post_type'    => 'shop_coupon'
            );

            $coupon_id = wp_insert_post($coupon);

            if ($coupon_id) {
                update_post_meta($coupon_id, 'discount_type', $discount_type);
                update_post_meta($coupon_id, 'coupon_amount', $amount);
                update_post_meta($coupon_id, 'individual_use', 'no');
                update_post_meta($coupon_id, 'usage_limit', '');
                update_post_meta($coupon_id, 'expiry_date', $expiry_date ? date('Y-m-d', strtotime($expiry_date)) : '');
                update_post_meta($coupon_id, 'apply_before_tax', 'yes');
                update_post_meta($coupon_id, 'free_shipping', 'no');

                $success = true;
            } else {
                $error = 'Errore durante la creazione del coupon.';
            }
        }
    }
}
?>

<h2>🎟️ Crea Nuovo Coupon</h2>

<?php if ($success): ?>
    <div style="padding: 10px; background: #d4edda; border-left: 5px solid #28a745; margin-bottom: 20px;">
        ✅ Coupon creato con successo!
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div style="padding: 10px; background: #f8d7da; border-left: 5px solid #dc3545; margin-bottom: 20px;">
        ❌ <?php echo esc_html($error); ?>
    </div>
<?php endif; ?>

<form method="post" style="background: white; padding: 20px; border-radius: 8px; max-width: 400px;">
    <?php wp_nonce_field('wpdl_add_coupon', 'wpdl_add_coupon_nonce'); ?>

    <label>Codice Coupon:</label><br>
    <input type="text" name="code" required style="width: 100%; margin-bottom: 10px;"><br>

    <label>Tipo di sconto:</label><br>
    <select name="discount_type" style="width: 100%; margin-bottom: 10px;">
        <option value="fixed_cart">Importo fisso sul carrello</option>
        <option value="percent">Percentuale</option>
        <option value="fixed_product">Importo fisso sul prodotto</option>
    </select><br>

    <label>Importo sconto:</label><br>
    <input type="number" step="0.01" name="amount" required style="width: 100%; margin-bottom: 10px;"><br>

    <label>Data scadenza (opzionale):</label><br>
    <input type="date" name="expiry_date" style="width: 100%; margin-bottom: 20px;"><br>

    <button type="submit" style="padding: 10px 20px; background: #0073aa; color: white; border: none; border-radius: 4px;">Crea Coupon</button>
</form>

<?php
// Recupera i coupon esistenti
$args = array(
    'posts_per_page' => 20,
    'post_type'      => 'shop_coupon',
    'post_status'    => 'publish',
);

$coupons = get_posts($args);

// Gestione cancellazione
if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['coupon_id']) && current_user_can('manage_woocommerce')) {
    $coupon_id = intval($_GET['coupon_id']);
    wp_delete_post($coupon_id, true);
    echo '<div style="padding:10px; background:#d4edda; border-left:5px solid #28a745; margin-top:20px;">Coupon eliminato con successo!</div>';
    // Aggiorna lista
    $coupons = get_posts($args);
}
?>

<h2>Lista Coupon</h2>

<table style="width: 100%; border-collapse: collapse; background: white; border-radius: 8px; box-shadow: 0 0 10px #ccc;">
    <thead>
        <tr style="background: #23282d; color: white;">
            <th style="padding: 10px; text-align: left;">Codice</th>
            <th style="padding: 10px; text-align: left;">Tipo Sconto</th>
            <th style="padding: 10px; text-align: left;">Importo</th>
            <th style="padding: 10px; text-align: left;">Scadenza</th>
            <th style="padding: 10px; text-align: left;">Azioni</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($coupons): ?>
            <?php foreach ($coupons as $coupon): ?>
                <?php
                $discount_type = get_post_meta($coupon->ID, 'discount_type', true);
                $amount = get_post_meta($coupon->ID, 'coupon_amount', true);
                $expiry_date = get_post_meta($coupon->ID, 'expiry_date', true);
                ?>
                <tr>
                    <td style="padding: 10px; border-bottom: 1px solid #ddd;"><?php echo esc_html($coupon->post_title); ?></td>
                    <td style="padding: 10px; border-bottom: 1px solid #ddd;"><?php echo esc_html($discount_type); ?></td>
                    <td style="padding: 10px; border-bottom: 1px solid #ddd;"><?php echo esc_html($amount); ?></td>
                    <td style="padding: 10px; border-bottom: 1px solid #ddd;"><?php echo $expiry_date ? esc_html($expiry_date) : '-'; ?></td>
                    <td style="padding: 10px; border-bottom: 1px solid #ddd;">
                        <a href="?wpdl-page=coupons&action=delete&coupon_id=<?php echo $coupon->ID; ?>" onclick="return confirm('Sei sicuro di voler eliminare questo coupon?');" style="color: red;">Elimina</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr><td colspan="5" style="padding: 10px;">Nessun coupon trovato.</td></tr>
        <?php endif; ?>
    </tbody>
</table>
