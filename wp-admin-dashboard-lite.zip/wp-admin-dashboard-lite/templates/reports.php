<?php
global $wpdb;

// Ottieni conteggio ordini per mese (anche shop_order_placehold in stato draft)
$results = $wpdb->get_results("
    SELECT 
        DATE_FORMAT(post_date, '%Y-%m') as month,
        COUNT(ID) as order_count
    FROM {$wpdb->prefix}posts
    WHERE post_type IN ('shop_order', 'shop_order_placehold')
    AND post_status IN ('wc-completed', 'wc-processing', 'draft')
    GROUP BY month
    ORDER BY month DESC
    LIMIT 6
");

$months = [];
$order_counts = [];

foreach (array_reverse($results) as $row) {
    $months[] = $row->month;
    $order_counts[] = intval($row->order_count);
}
?>

<h2>📈 Ordini negli Ultimi 6 Mesi</h2>
<canvas id="ordersChart" width="600" height="300"></canvas>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const ctx = document.getElementById('ordersChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [{
                label: 'Numero Ordini',
                data: <?php echo json_encode($order_counts); ?>,
                borderColor: 'rgba(54, 162, 235, 1)',
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    stepSize: 1
                }
            }
        }
    });
});
</script>
