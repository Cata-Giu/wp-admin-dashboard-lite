<?php
if ( ! current_user_can('manage_woocommerce') ) {
    echo '<p>Accesso negato.</p>';
    return;
}

$category_filter = isset($_GET['category']) ? sanitize_text_field($_GET['category']) : '';
$status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';

// Costruisci i parametri di query
$args = [
    'post_type' => 'product',
    'posts_per_page' => -1,
    'post_status' => ['publish', 'draft'],
    'orderby' => 'title',
    'order' => 'ASC',
    'tax_query' => [],
];

if ($status_filter === 'draft') {
    $args['post_status'] = 'draft';
} elseif ($status_filter === 'publish') {
    $args['post_status'] = 'publish';
}

if ($category_filter) {
    $args['tax_query'][] = [
        'taxonomy' => 'product_cat',
        'field'    => 'slug',
        'terms'    => $category_filter,
    ];
}

$query = new WP_Query($args);
$categories = get_terms('product_cat');
?>

<h2>🛒 Prodotti</h2>

<form method="get" style="margin-bottom: 20px; display: flex; gap: 10px;">
    <input type="hidden" name="wpdl-page" value="products">

    <select name="category">
        <option value="">Tutte le categorie</option>
        <?php foreach ($categories as $cat): ?>
            <option value="<?php echo esc_attr($cat->slug); ?>" <?php selected($category_filter, $cat->slug); ?>>
                <?php echo esc_html($cat->name); ?>
            </option>
        <?php endforeach; ?>
    </select>

    <select name="status">
        <option value="">Tutti gli stati</option>
        <option value="publish" <?php selected($status_filter, 'publish'); ?>>Pubblicati</option>
        <option value="draft" <?php selected($status_filter, 'draft'); ?>>Bozze</option>
    </select>

    <button type="submit">Filtra</button>
</form>

<table style="width: 100%; border-collapse: collapse; background: white;">
    <thead>
        <tr style="background: #f1f1f1;">
            <th style="padding: 10px; border: 1px solid #ddd;">Nome</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Prezzo</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Stock</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Stato</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Categoria</th>
        </tr>
    </thead>
    <tbody>
    <?php if ($query->have_posts()) : ?>
        <?php while ($query->have_posts()) : $query->the_post(); ?>
            <?php
            $product = wc_get_product(get_the_ID());
            $categories = wp_get_post_terms(get_the_ID(), 'product_cat', ['fields' => 'names']);
            ?>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php the_title(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo wc_price($product->get_price()); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $product->get_stock_quantity(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo get_post_status(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo implode(', ', $categories); ?></td>
            </tr>
        <?php endwhile; ?>
        <?php wp_reset_postdata(); ?>
    <?php else : ?>
        <tr>
            <td colspan="5" style="padding: 10px; border: 1px solid #ddd; text-align: center;">Nessun prodotto trovato.</td>
        </tr>
    <?php endif; ?>
</tbody>
