<?php
if ( ! current_user_can('manage_woocommerce') ) {
    echo '<p>Accesso negato.</p>';
    return;
}

$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['wpdl_add_product_nonce']) && wp_verify_nonce($_POST['wpdl_add_product_nonce'], 'wpdl_add_product')) {
    $title = sanitize_text_field($_POST['title']);
    $description = sanitize_textarea_field($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    $categories = isset($_POST['categories']) ? array_map('intval', $_POST['categories']) : [];

    $post_id = wp_insert_post([
        'post_title'   => $title,
        'post_content' => $description,
        'post_status'  => 'publish',
        'post_type'    => 'product',
    ]);

    if ($post_id) {
        wp_set_object_terms($post_id, $categories, 'product_cat');

        update_post_meta($post_id, '_regular_price', $price);
        update_post_meta($post_id, '_price', $price);
        update_post_meta($post_id, '_stock', $stock);
        update_post_meta($post_id, '_stock_status', $stock > 0 ? 'instock' : 'outofstock');
        update_post_meta($post_id, '_manage_stock', 'yes');

        // Immagine
        if (!empty($_FILES['product_image']['name'])) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
            $uploaded = media_handle_upload('product_image', $post_id);
            if (!is_wp_error($uploaded)) {
                set_post_thumbnail($post_id, $uploaded);
            }
        }

        $success = true;
    }
}

$all_categories = get_terms([
    'taxonomy' => 'product_cat',
    'hide_empty' => false,
]);
?>

<h2>➕ Aggiungi Nuovo Prodotto</h2>

<?php if ($success): ?>
    <div style="padding: 10px; background: #d4edda; border-left: 5px solid #28a745; margin-bottom: 20px;">
        ✅ Prodotto aggiunto con successo!
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" style="background: white; padding: 20px; border-radius: 8px;">
    <?php wp_nonce_field('wpdl_add_product', 'wpdl_add_product_nonce'); ?>

    <label>Nome prodotto:</label><br>
    <input type="text" name="title" required style="width: 100%; margin-bottom: 10px;"><br>

    <label>Descrizione:</label><br>
    <textarea name="description" rows="5" required style="width: 100%; margin-bottom: 10px;"></textarea><br>

    <label>Prezzo (€):</label><br>
    <input type="number" step="0.01" name="price" required style="width: 100%; margin-bottom: 10px;"><br>

    <label>Stock:</label><br>
    <input type="number" name="stock" required style="width: 100%; margin-bottom: 10px;"><br>

    <label>Immagine prodotto:</label><br>
    <input type="file" name="product_image" accept="image/*" style="margin-bottom: 10px;"><br>

    <label>Categorie:</label><br>
    <select name="categories[]" multiple style="width: 100%; margin-bottom: 20px;">
        <?php foreach ($all_categories as $cat): ?>
            <option value="<?php echo esc_attr($cat->term_id); ?>"><?php echo esc_html($cat->name); ?></option>
        <?php endforeach; ?>
    </select><br>

    <button type="submit" style="padding: 10px 20px; background: #0073aa; color: white; border: none; border-radius: 4px;">Aggiungi Prodotto</button>
</form>
