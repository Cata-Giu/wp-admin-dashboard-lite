<?php
if (!function_exists('wc_get_orders')) {
    echo "<p>WooCommerce non è attivo.</p>";
    return;
}

$orders = wc_get_orders([
    'limit' => 20,
    'orderby' => 'date',
    'order' => 'DESC'
]);
?>

<h2>Ordini recenti</h2>

<table style="width: 100%; border-collapse: collapse; background: white;">
    <thead>
        <tr style="background: #eee;">
            <th style="padding: 10px; border: 1px solid #ddd;">ID</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Cliente</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Totale</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Articoli</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Stato</th>
            <th style="padding: 10px; border: 1px solid #ddd;">Data</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($orders as $order): ?>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $order->get_id(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $order->get_formatted_order_total(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $order->get_item_count(); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo wc_get_order_status_name($order->get_status()); ?></td>
                <td style="padding: 10px; border: 1px solid #ddd;"><?php echo $order->get_date_created()->date_i18n('d/m/Y H:i'); ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
