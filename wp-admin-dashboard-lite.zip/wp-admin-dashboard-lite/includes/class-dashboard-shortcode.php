<?php
if (!defined('ABSPATH')) exit;

class WP_Admin_Dashboard_Shortcode {

    public static function render() {
        include WPDL_PATH . 'templates/dashboard.php';
    }
}
