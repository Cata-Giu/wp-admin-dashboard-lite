<?php
if (!defined('ABSPATH')) exit;

class WP_Admin_Dashboard_Stats {

    public static function get_stats() {
        $data = [];

        // Vendite nette del mese
        $start_of_month = date('Y-m-01');
        $end_of_month = date('Y-m-t');

        $orders = wc_get_orders([
            'status' => 'completed',
            'limit'  => -1,
            'date_created' => $start_of_month . '...' . $end_of_month
        ]);

        $total_sales = 0;
        foreach ($orders as $order) {
            $total_sales += (float) $order->get_total();
        }
        $data['total_sales'] = wc_price($total_sales);

        // Numero ordini completati
        $data['completed_orders'] = count($orders);

        // Prodotti esauriti
        $out_of_stock = wc_get_products([
            'stock_status' => 'outofstock',
            'limit' => -1
        ]);
        $data['out_of_stock'] = count($out_of_stock);

        return $data;
    }
}
