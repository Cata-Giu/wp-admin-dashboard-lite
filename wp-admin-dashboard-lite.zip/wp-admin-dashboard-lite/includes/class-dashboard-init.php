<?php
if (!defined('ABSPATH')) exit;

class WP_Admin_Dashboard_Lite_Init {

    public function __construct() {
        $this->includes();

        // Fai check accesso *prima* di registrare lo shortcode, 
        // così eviti di mostrare la dashboard a utenti non autorizzati
        WP_Admin_Dashboard_Auth::check_user();

        add_shortcode('admin_dashboard', [$this, 'render_dashboard']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    private function includes() {
        require_once WPDL_PATH . 'includes/class-dashboard-shortcode.php';
        require_once WPDL_PATH . 'includes/class-auth.php';
        WP_Admin_Dashboard_Auth::check_user();
        require_once WPDL_PATH . 'includes/class-dashboard-stats.php';

        // altri moduli da aggiungere più avanti
    }

    public function render_dashboard($atts) {
        ob_start();
        // Fallback sicurezza, ma teoricamente non serve più
        if (!is_user_logged_in() || !current_user_can('manage_woocommerce')) {
            echo '<p>Accesso non autorizzato.</p>';
        } else {
            WP_Admin_Dashboard_Shortcode::render();
        }
        return ob_get_clean();
    }

    public function enqueue_assets() {
        wp_enqueue_style('wpdl-style', WPDL_URL . 'assets/css/style.css');
        wp_enqueue_script('wpdl-script', WPDL_URL . 'assets/js/script.js', [], false, true);
    }
}

new WP_Admin_Dashboard_Lite_Init();
