<?php
// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class WP_Admin_Dashboard_Auth {

    public static function check_user() {
        // Se utente non loggato, reindirizza al login
        if (!is_user_logged_in()) {
            wp_redirect(wp_login_url());
            exit;
        }

        $user = wp_get_current_user();

        // Controlla che l’utente abbia il ruolo 'administrator' o 'shop_manager'
        $allowed_roles = ['administrator', 'shop_manager'];
        if (array_intersect($allowed_roles, (array) $user->roles) === []) {
            wp_die(__('Accesso negato. Non hai i permessi necessari.', 'wp-admin-dashboard-lite'));
            exit;
        }
    }
}
