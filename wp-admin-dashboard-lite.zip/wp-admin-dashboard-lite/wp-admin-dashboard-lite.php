<?php
/**
 * Plugin Name: WP Admin Dashboard Lite
 * Description: Dashboard frontend per amministratori WooCommerce. Mostra statistiche, ordini, prodotti, coupon e report.
 * Version: 1.0.0
 * Author: Il Tuo Nome
 */

// Impedisce l'accesso diretto al file
if (!defined('ABSPATH')) exit;

// Definisce costanti utili
define('WPDL_PATH', plugin_dir_path(__FILE__));
define('WPDL_URL', plugin_dir_url(__FILE__));

// Carica i file principali
add_action('plugins_loaded', function() {
    require_once WPDL_PATH . 'includes/class-dashboard-init.php';
});

add_action('wp_enqueue_scripts', function() {
    if (isset($_GET['wpdl-page']) && in_array($_GET['wpdl-page'], ['reports'])) {
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true);
    }
});

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_style('wpdl-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
});
