//attiva il caricamento delle sezioni dinamiche
document.addEventListener('DOMContentLoaded', function () {
    const links = document.querySelectorAll('.wpdl-menu-link');
    const content = document.getElementById('wpdl-content');

    links.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();
            const page = this.dataset.page;
            content.innerHTML = `<h3>Caricamento ${page}...</h3>`;
            // carica via AJAX o switch su template PHP
        });
    });
});
